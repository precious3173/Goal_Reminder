package com.example.mygoals;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyGoalAdapter extends RecyclerView.Adapter<MyGoalAdapter.Goals>  {
ArrayList<MyGoalArrayList>myGoalArrayLists = new ArrayList<>();

    public MyGoalAdapter (ArrayList<MyGoalArrayList>myGoalArrayLists) {
        this.myGoalArrayLists = myGoalArrayLists;
    }
    @NonNull
    @Override
    public MyGoalAdapter.Goals onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_layout, parent, false);
        return new MyGoalAdapter.Goals(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyGoalAdapter.Goals holder, int position) {

        MyGoalArrayList myGoalArrayList = myGoalArrayLists.get(position);

        String goalDate = myGoalArrayList.getGoalDate();
        String goalTitle = myGoalArrayList.getGoalTitle();
        String goalDescription = myGoalArrayList.getGoalDescription();

        holder.goalDate.setText(goalDate);
        holder.goalTitle.setText(goalTitle);



    }

    @Override
    public int getItemCount() {
        return myGoalArrayLists.size();
    }



    public class Goals extends RecyclerView.ViewHolder {

        TextView goalTitle, goalDate;

        public Goals(@NonNull View itemView) {
            super(itemView);
            goalTitle = itemView.findViewById(R.id.goalTitle);
            goalDate = itemView.findViewById(R.id.goalDate);

        }


    }
}