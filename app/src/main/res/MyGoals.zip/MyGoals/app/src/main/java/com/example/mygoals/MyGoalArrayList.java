package com.example.mygoals;

public class MyGoalArrayList {

    String goalDate;
    String goalDescription;
    String goalTitle;

    public MyGoalArrayList (String goalDate, String goalDescription, String goalTitle) {

        this.goalDate = goalDate;
        this.goalDescription = goalDescription;
        this.goalTitle = goalTitle;
    }

    public String getGoalDate() {
        return goalDate;
    }

    public void setGoalDate(String goalDate) {
        this.goalDate = goalDate;
    }

    public String getGoalDescription() {
        return goalDescription;
    }

    public void setGoalDescription(String goalDescription) {
        this.goalDescription = goalDescription;
    }

    public String getGoalTitle() {
        return goalTitle;
    }

    public void setGoalTitle(String goalTitle) {
        this.goalTitle = goalTitle;
    }
}
